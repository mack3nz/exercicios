let numeros = [12, 9, 14, 5, 6, 2, 7, 8]
let i = 0

while (i < numeros.length) {
    if (numeros[i] % 2 == 0) {
        console.log(numeros[i])
    }
    i++
}

