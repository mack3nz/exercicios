let vetor = [1, 5, 7];

let vetorResultante = [];

for (let i = 0; i < vetor.length; i++) {
    vetorResultante[i] = vetor[i] * 2;
}

console.log(vetorResultante);
