let frutas = ["maçã", "banana", "laranja", "bergamota", "mamão"]
console.log(frutas[3])