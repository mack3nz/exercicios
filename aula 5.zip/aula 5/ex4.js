let matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

let numero = matriz[1][2]; 

console.log(`O número na segunda linha e terceira coluna é: ${numero}`);
