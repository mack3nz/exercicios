let frutas = [1, 2, 3]

frutas.push(4)

frutas.shift()

console.log(frutas)
