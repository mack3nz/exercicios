// contar ate 10
let cont = 0
for (let i = 1; i <= 10; i = i + 1) {
    cont++
    console.log(cont)
}

